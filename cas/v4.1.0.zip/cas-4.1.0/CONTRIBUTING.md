# Contributor Guidelines

Please see the [Contributor Guidelines](http://jasig.github.io/cas/developer/Contributor-Guidelines.html) for more info.